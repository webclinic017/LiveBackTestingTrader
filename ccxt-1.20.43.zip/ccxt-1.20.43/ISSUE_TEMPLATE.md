MUST READ THIS BEFORE SUBMITTING ISSUES (read the link, then delete this message before submitting):

https://github.com/ccxt/ccxt/blob/master/CONTRIBUTING.md#how-to-submit-an-issue

Please make sure your local version of ccxt is up to date with this repo. You can check by comparing the output of `ccxt.version` to https://github.com/ccxt/ccxt/blob/master/package.json#L3

- OS:
- Programming Language version:
- CCXT version:
- Exchange:
- Method:
